import { useEffect, useState } from 'react';
import { auth, db } from '../firebase/config';
import { onValue, ref } from 'firebase/database';

export default function useCartCount() {
  const [count, setCount] = useState(0);

  useEffect(() => {
    const user = auth.currentUser;
    if (!user) return;

    const cartRef = ref(db, `users/${user.uid}/cart`);
    const unsubscribe = onValue(cartRef, (snapshot) => {
      const data = snapshot.val() as Record<string, { quantity?: number }>;
      if (data) {
        const total = Object.values(data).reduce(
          (sum: any, item: any) => sum + (item.quantity || 1),
          0
        );
        setCount(total);
      } else {
        setCount(0);
      }
    });

    return () => unsubscribe();
  }, []);

  return count;
}
