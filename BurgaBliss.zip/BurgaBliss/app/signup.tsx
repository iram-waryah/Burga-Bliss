import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Image,
  StyleSheet,
  ScrollView,
  Modal,
  Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { createUserWithEmailAndPassword, sendEmailVerification } from 'firebase/auth';
import { auth } from '../firebase/config';
import { MaterialIcons, FontAwesome } from '@expo/vector-icons';

import InputField from '../components/InputField';

export default function SignupScreen() {
  const router = useRouter();

  const [email, setEmail] = useState('');
  const [emailError, setEmailError] = useState('');

  const [password, setPassword] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [passwordValidMsg, setPasswordValidMsg] = useState('');

  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [confirmTouched, setConfirmTouched] = useState(false);
  const [passwordMatched, setPasswordMatched] = useState(false);

  const [successModalVisible, setSuccessModalVisible] = useState(false);

  useEffect(() => {
    if (confirmTouched) setPasswordValidMsg('');
  }, [confirmTouched]);

  const validateEmail = (email: string): void => {
    const pattern = /^[\w.-]+@gmail\.com$/;
    if (!pattern.test(email)) {
      setEmailError('Please enter a valid Gmail address');
    } else {
      setEmailError('');
    }
  };

  const validatePassword = (pwd: string) => {
    const minLength = pwd.length >= 8;
    const hasLetter = /[a-zA-Z]/.test(pwd);
    const hasNumber = /[0-9]/.test(pwd);
    const hasSymbol = /[!@#$%^&*(),.?":{}|<>]/.test(pwd);

    if (!minLength || !hasLetter || !hasNumber || !hasSymbol) {
      setPasswordError('Password must be 8+ chars with letter, number & symbol');
      setPasswordValidMsg('');
    } else {
      setPasswordError('');
      if (!confirmTouched) setPasswordValidMsg('Strong password');
    }

    setPasswordMatched(pwd === confirmPassword);
  };

  const handleSignup = async () => {
    if (!email || !password || !confirmPassword) {
      alert('Please complete all fields');
      return;
    }

    if (password !== confirmPassword) {
      alert("Passwords don't match");
      return;
    }

    if (emailError || passwordError) {
      alert('Fix the validation errors before signing up.');
      return;
    }

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      await sendEmailVerification(user);

      setSuccessModalVisible(true);

      setTimeout(() => {
        setSuccessModalVisible(false);
        alert('A verification link has been sent to your Gmail. Please verify before logging in.');
        router.replace('/login');
      }, 2500);
    } catch (error: any) {
      let msg = error.message || 'Signup failed. Try again.';
      if (error.code === 'auth/email-already-in-use') {
        msg = 'This email is already registered.';
      }
      Alert.alert('Signup Error', msg);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Image
        source={require('../assets/images/burgabliss-logo.png')}
        style={styles.logo}
        resizeMode="contain"
      />

      <View style={styles.inputWrapper}>
        <InputField
          icon="email"
          placeholder="Enter your email address"
          value={email}
          onChangeText={(text) => {
            setEmail(text);
            validateEmail(text);
          }}
        />
        <Text style={emailError ? styles.errorText : styles.placeholderSpace}>
          {emailError || ' '}
        </Text>
      </View>

      <View style={styles.inputWrapper}>
        <InputField
          icon="lock"
          placeholder="Enter your password"
          value={password}
          onChangeText={(text) => {
            setPassword(text);
            validatePassword(text);
          }}
          secureTextEntry={!showPassword}
          toggleVisibility={() => setShowPassword(!showPassword)}
          isPassword
        />
        {passwordError ? (
          <Text style={styles.errorText}>{passwordError}</Text>
        ) : passwordValidMsg ? (
          <View style={styles.successRow}>
            <Text style={styles.successText}>{passwordValidMsg}</Text>
          </View>
        ) : (
          <Text style={styles.placeholderSpace}> </Text>
        )}
      </View>

      <View style={styles.inputWrapper}>
        <InputField
          icon="lock-outline"
          placeholder="Confirm your password"
          value={confirmPassword}
          onChangeText={(text) => {
            setConfirmPassword(text);
            setConfirmTouched(true);
            setPasswordMatched(password === text);
          }}
          secureTextEntry={!showConfirm}
          toggleVisibility={() => setShowConfirm(!showConfirm)}
          isPassword
        />
        {confirmTouched && passwordMatched ? (
          <View style={styles.successRow}>
            <Text style={styles.successText}>Password matched</Text>
          </View>
        ) : (
          <Text style={styles.placeholderSpace}> </Text>
        )}
      </View>

      <TouchableOpacity style={styles.signupButton} onPress={handleSignup}>
        <Text style={styles.signupButtonText}>Sign Up</Text>
      </TouchableOpacity>

      <View style={styles.divider}>
        <View style={styles.line} />
        <Text style={styles.orText}>Sign up with</Text>
        <View style={styles.line} />
      </View>

      <View style={styles.socialContainer}>
        <FontAwesome name="google" size={28} color="#DB4437" />
        <MaterialIcons name="email" size={28} color="#4285F4" />
      </View>

      <TouchableOpacity onPress={() => router.push('/login')}>
        <Text style={styles.footerText}>
          Already have an account? <Text style={{ color: '#ff9900' }}>Sign In</Text>
        </Text>
      </TouchableOpacity>

      <Modal
        visible={successModalVisible}
        transparent
        animationType="slide"
        onRequestClose={() => setSuccessModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Registration successful!</Text>
            <Text style={styles.modalSubtitle}>Please verify your email before logging in.</Text>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 24,
    backgroundColor: '#fff',
    flexGrow: 1,
    alignItems: 'center',
  },
  logo: {
    width: 180,
    height: 140,
    marginBottom: 35,
    marginTop: 30,
  },
  inputWrapper: {
    width: '100%',
    marginBottom: 4,
  },
  signupButton: {
    backgroundColor: '#ff9900',
    paddingVertical: 14,
    borderRadius: 30,
    width: '100%',
    alignItems: 'center',
    marginBottom: 25,
    marginTop: 10,
  },
  signupButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    width: '100%',
  },
  line: {
    flex: 1,
    height: 1,
    backgroundColor: '#ccc',
  },
  orText: {
    marginHorizontal: 10,
    color: '#999',
  },
  footerText: {
    textAlign: 'center',
    color: '#666',
    fontSize: 14,
  },
  errorText: {
    color: 'red',
    fontSize: 13,
    marginTop: 2,
    marginBottom: 6,
    paddingLeft: 10,
    alignSelf: 'flex-start',
  },
  placeholderSpace: {
    fontSize: 13,
    marginTop: 2,
    marginBottom: 6,
    opacity: 0,
    paddingLeft: 10,
    alignSelf: 'flex-start',
  },
  successRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 2,
    marginBottom: 6,
    paddingLeft: 10,
  },
  successText: {
    color: 'green',
    fontSize: 13,
    marginLeft: 4,
    alignSelf: 'flex-start',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: 30,
    borderRadius: 20,
    alignItems: 'center',
    width: '80%',
    elevation: 5,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: 'green',
    marginTop: 12,
    textAlign: 'center',
  },
  modalSubtitle: {
    fontSize: 14,
    color: '#444',
    marginTop: 6,
    textAlign: 'center',
  },
  socialContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 24,
    marginBottom: 30,
  },
});
