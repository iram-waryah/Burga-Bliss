import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  ScrollView,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { auth, db } from '../../firebase/config';
import { ref, get, set } from 'firebase/database';
import useCartCount from '../../hooks/useCartCount';

export default function BurgerDetails() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const [burger, setBurger] = useState<any>(null);
  const [isFavorite, setIsFavorite] = useState(false);
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(true);
  const cartCount = useCartCount();

  useEffect(() => {
    const fetchBurgerAndStatus = async () => {
      try {
        // Fetch burger details
        const burgerSnapshot = await get(ref(db, `burgers/${id}`));
        if (burgerSnapshot.exists()) {
          setBurger(burgerSnapshot.val());
          
          // Check favorite status if user is logged in
          const user = auth.currentUser;
          if (user) {
            const favoriteSnapshot = await get(ref(db, `users/${user.uid}/favorites/${id}`));
            setIsFavorite(favoriteSnapshot.exists());
          }
        } else {
          Alert.alert('Error', 'Burger not found.');
        }
      } catch (error) {
        console.error('Error:', error);
        Alert.alert('Error', 'Failed to load burger.');
      } finally {
        setLoading(false);
      }
    };

    fetchBurgerAndStatus();
  }, [id]);

  const toggleFavorite = async () => {
    const user = auth.currentUser;
    if (!user) {
      Alert.alert('Please login first');
      return;
    }

    const favoriteRef = ref(db, `users/${user.uid}/favorites/${id}`);

    try {
      if (isFavorite) {
        // Remove from favorites
        await set(favoriteRef, null);
        setIsFavorite(false);
        Alert.alert('Removed', `"${burger.name}" has been removed from your favorites.`);
      } else {
        // Add to favorites
        await set(favoriteRef, {
          id,
          name: burger.name,
          image: burger.image ?? '',
          rating: burger.rating,
          price: burger.price,
          timestamp: new Date().toISOString(),
        });
        setIsFavorite(true);
        Alert.alert('Added', `"${burger.name}" has been added to your favorites.`);
      }
    } catch (error) {
      console.error('Error toggling favorite:', error);
      Alert.alert('Error', 'Could not update favorites.');
    }
  };

  const addToCart = async () => {
    const user = auth.currentUser;
    if (!user) {
      Alert.alert('Please login first');
      return;
    }

    try {
      // First check if the item already exists in cart
      const cartRef = ref(db, `users/${user.uid}/cart/${id}`);
      const cartSnapshot = await get(cartRef);
      const existingQuantity = cartSnapshot.exists() ? cartSnapshot.val().quantity : 0;

      // Set the new quantity (existing + selected)
      await set(cartRef, {
        id,
        name: burger.name,
        image: burger.image ?? '',
        price: burger.price,
        quantity: existingQuantity + quantity,
        timestamp: new Date().toISOString(),
      });

      Alert.alert(
        'Added to Cart', 
        `${quantity}x ${burger.name} ${quantity === 1 ? 'has' : 'have'} been added to your cart.`
      );
    } catch {
      Alert.alert('Error', 'Could not add to cart.');
    }
  };


  const Ingredient = ({ icon, label }: { icon: string; label: string }) => (
    <View style={styles.ingredient}>
      <Text style={styles.ingredientIcon}>{icon}</Text>
      <Text style={styles.ingredientLabel}>{label}</Text>
    </View>
  );

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#FFC107" />
      </View>
    );
  }

  if (!burger) {
    return (
      <View style={styles.center}>
        <Text style={{ fontSize: 16 }}>Burger not found.</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* Top Icons */}
      <View style={styles.topIcons}>
        <TouchableOpacity onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={26} color="#000" />
        </TouchableOpacity>

        <View style={{ flexDirection: 'row', gap: 12 }}>
          <TouchableOpacity onPress={toggleFavorite}>
            <Ionicons
              name={isFavorite ? 'heart' : 'heart-outline'}
              size={26}
              color={isFavorite ? '#FF3B30' : '#666'}
            />
          </TouchableOpacity>

          <TouchableOpacity onPress={() => router.push('/cart')} style={{ position: 'relative' }}>
            <Ionicons name="cart-outline" size={26} color="#000" />
            {cartCount > 0 && (
              <View
                style={{
                  position: 'absolute',
                  top: -4,
                  right: -6,
                  backgroundColor: '#FF3D00',
                  borderRadius: 10,
                  paddingHorizontal: 5,
                  paddingVertical: 1,
                  minWidth: 18,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Text style={{ color: '#fff', fontSize: 12, fontWeight: 'bold' }}>
                  {cartCount}
                </Text>
              </View>
            )}
          </TouchableOpacity>
        </View>
      </View>

      {/* Burger Image */}
      <Image source={{ uri: burger.image }} style={styles.image} />

      <View style={styles.content}>
        <Text style={styles.name}>{burger.name}</Text>

        <TouchableOpacity
          style={styles.row}
          onPress={() =>
            router.push({
              pathname: '/review',
              params: { id },
            })
          }
        >
          <Ionicons name="star" size={18} color="#FFC107" />
          <Text style={styles.rating}>{burger.rating}</Text>
        </TouchableOpacity>

        {/* Quantity Selector */}
        <View style={styles.counter}>
          <TouchableOpacity
            style={styles.counterBtn}
            onPress={() => setQuantity(Math.max(1, quantity - 1))}
          >
            <Text>-</Text>
          </TouchableOpacity>
          <Text style={styles.counterNum}>{quantity}</Text>
          <TouchableOpacity
            style={styles.counterBtn}
            onPress={() => setQuantity(quantity + 1)}
          >
            <Text>+</Text>
          </TouchableOpacity>
        </View>

        {/* Ingredients */}
        <Text style={styles.subheading}>Ingredients</Text>
        <View style={styles.ingredients}>
          <Ingredient icon="🧀" label="Cheese" />
          <Ingredient icon="🧅" label="Onion" />
          <Ingredient icon="🥩" label="Meat" />
          <Ingredient icon="🥬" label="Veggies" />
        </View>

        {/* Description */}
        <Text style={styles.subheading}>Description</Text>
        <Text style={styles.description}>{burger.description}</Text>

        {/* Add to Cart */}
        <View style={styles.cartRow}>
          <Text style={styles.price}>PKR {burger.price}</Text>
          <TouchableOpacity style={styles.cartBtn} onPress={addToCart}>
            <Ionicons name="cart" size={18} color="#fff" style={{ marginRight: 6 }} />
            <Text style={styles.cartText}>Add to cart</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { paddingBottom: 30, backgroundColor: '#fff' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  topIcons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
    marginTop: 30,
  },
  image: { width: '100%', height: 220, resizeMode: 'contain' },
  content: { paddingHorizontal: 16 },
  name: { fontSize: 24, fontWeight: 'bold', marginVertical: 10 },
  row: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  rating: { fontSize: 16, marginLeft: 6 },
  counter: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 10,
    gap: 10,
  },
  counterBtn: {
    backgroundColor: '#eee',
    padding: 8,
    borderRadius: 10,
  },
  counterNum: { fontSize: 16 },
  subheading: { fontSize: 18, fontWeight: '600', marginTop: 20, marginBottom: 8 },
  ingredients: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  ingredient: {
    alignItems: 'center',
    width: 70,
  },
  ingredientIcon: {
    fontSize: 24,
    marginBottom: 4,
  },
  ingredientLabel: {
    fontSize: 14,
  },
  description: { fontSize: 14, lineHeight: 20, color: '#444', marginTop: 10 },
  cartRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 30,
  },
  price: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
  },
  cartBtn: {
    backgroundColor: '#000',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 30,
    flexDirection: 'row',
    alignItems: 'center',
  },
  cartText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
});
