// app/login.tsx (fixed)
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Image,
  ScrollView,
  Alert,
} from 'react-native';
import { MaterialIcons, FontAwesome } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../firebase/config';

export default function LoginScreen() {
  const router = useRouter();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [successModalVisible, setSuccessModalVisible] = useState(false);

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Error', 'Please enter both email and password');
      return;
    }

    try {
      // ✅ ALWAYS login using Firebase Auth
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Admin Routing
      if (user.email === 'adminburgabliss@gmail.com') {
        router.replace('/admin/dashboard');
        return;
      }

      // Normal user email verification
      if (!user.emailVerified) {
        Alert.alert(
          'Email Not Verified',
          'Please verify your email before logging in.\nCheck your inbox or spam folder.'
        );
        return;
      }

      // Show login success modal
      setSuccessModalVisible(true);
      setTimeout(() => {
        setSuccessModalVisible(false);
        router.replace('/(tabs)/home');
      }, 2500);

    } catch (error: any) {
      let msg = 'Login failed. Please try again.';
      if (error.code === 'auth/invalid-email') msg = 'Invalid email address';
      else if (error.code === 'auth/user-not-found') msg = 'No user found';
      else if (error.code === 'auth/wrong-password') msg = 'Incorrect password';
      Alert.alert('Login Error', msg);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      <View style={styles.header}>
        <Image
          source={require('../assets/images/burgabliss-logo.png')}
          style={styles.logo}
          resizeMode="contain"
        />
      </View>

      <View style={styles.content}>
        <View style={styles.inputWrapper}>
          <MaterialIcons name="email" size={20} color="#888" style={styles.icon} />
          <TextInput
            placeholder="Enter your email address"
            value={email}
            onChangeText={setEmail}
            style={styles.inputField}
            keyboardType="email-address"
            autoCapitalize="none"
          />
        </View>

        <View style={styles.inputWrapper}>
          <MaterialIcons name="lock" size={20} color="#888" style={styles.icon} />
          <TextInput
            placeholder="Enter your password"
            value={password}
            onChangeText={setPassword}
            style={styles.inputField}
            secureTextEntry={!showPassword}
          />
          <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
            <MaterialIcons
              name={showPassword ? 'visibility-off' : 'visibility'}
              size={20}
              color="#888"
            />
          </TouchableOpacity>
        </View>

        <TouchableOpacity onPress={() => router.push('/forget-password')}>
          <Text style={styles.forgot}>Forgot Password?</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.loginButton} onPress={handleLogin}>
          <Text style={styles.loginButtonText}>Sign In</Text>
        </TouchableOpacity>

        <View style={styles.divider}>
          <View style={styles.line} />
          <Text style={styles.orText}>Sign in with</Text>
          <View style={styles.line} />
        </View>

        <View style={styles.socialContainer}>
          <FontAwesome name="google" size={28} color="#DB4437" />
          <MaterialIcons name="email" size={28} color="#4285F4" />
        </View>

        <TouchableOpacity onPress={() => router.push('/signup')}>
          <Text style={styles.signupLink}>
            Don’t have an account?{' '}
            <Text style={{ color: '#ff9900' }}>Sign Up</Text>
          </Text>
        </TouchableOpacity>
      </View>

      {successModalVisible && (
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <MaterialIcons name="check-circle" size={50} color="green" />
            <Text style={styles.modalTitle}>Login successful!</Text>
            <Text style={styles.modalSubtitle}>Welcome back to BurgaBliss</Text>
          </View>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scrollContainer: { backgroundColor: '#fff', flexGrow: 1 },
  header: {
    width: '100%',
    backgroundColor: '#FFC107',
    alignItems: 'center',
    paddingVertical: 40,
    borderBottomLeftRadius: 40,
    borderBottomRightRadius: 40,
  },
  logo: { width: 150, height: 100 },
  content: { paddingHorizontal: 24, paddingTop: 50, paddingBottom: 50 },
  inputWrapper: {
    flexDirection: 'row', alignItems: 'center', borderWidth: 1,
    borderColor: '#ccc', borderRadius: 30,
    paddingHorizontal: 14, backgroundColor: '#f9f9f9', marginBottom: 30,
  },
  icon: { marginRight: 8 },
  inputField: { flex: 1, paddingVertical: 12 },
  forgot: {
    alignSelf: 'flex-end', color: '#e63946',
    marginTop: -20, marginBottom: 40, fontWeight: '500'
  },
  loginButton: {
    backgroundColor: '#ff9900', paddingVertical: 14,
    borderRadius: 30, alignItems: 'center', marginBottom: 25,
  },
  loginButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  divider: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
  line: { flex: 1, height: 1, backgroundColor: '#ccc' },
  orText: { marginHorizontal: 10, color: '#888' },
  socialContainer: { flexDirection: 'row', justifyContent: 'center', gap: 24, marginBottom: 30 },
  signupLink: { textAlign: 'center', color: '#666', fontSize: 14 },
  modalOverlay: {
    position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.4)', justifyContent: 'center', alignItems: 'center', zIndex: 999,
  },
  modalContent: {
    backgroundColor: '#fff', padding: 30, borderRadius: 20,
    alignItems: 'center', width: '80%', elevation: 5,
  },
  modalTitle: {
    fontSize: 18, fontWeight: '600', color: 'green',
    marginTop: 12, textAlign: 'center',
  },
  modalSubtitle: {
    fontSize: 14, color: '#444', marginTop: 6, textAlign: 'center',
  },
});
