import React from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  SafeAreaView,
} from 'react-native';
import { useRouter } from 'expo-router';

export default function LandingScreen() {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" backgroundColor="#FFC107" />
      <View style={styles.container}>
        {/* Brand Name */}
        <Text style={styles.brand}>BurgaBliss</Text>
        <Text style={styles.tagline}>Delicious Burgers Delivered to Your Doorstep</Text>

        {/* Burger Image */}
        <Image
          source={require('../assets/images/stacked-burger.png')}
          style={styles.burgerImage}
          resizeMode="contain"
        />

        {/* Highlight Title */}
        <Text style={styles.title}>Craving Burgers?</Text>
        <Text style={styles.subtitle}>BurgaBliss Delivers Fast!</Text>

        {/* Description */}
        <Text style={styles.description}>
          BurgaBliss is your go-to burger delivery app —{'\n'}
          hot, juicy, and delivered right to your doorstep!
        </Text>

        {/* Buttons */}
        <View style={styles.buttonRow}>
          <TouchableOpacity
            style={styles.loginBtn}
            onPress={() => router.push('/login')}
          >
            <Text style={styles.loginText}>Log In</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.signupBtn}
            onPress={() => router.push('/signup')}
          >
            <Text style={styles.signupText}>Sign Up</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}

export const screenOptions = {
  headerShown: false,
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FFC107',
  },
  container: {
    flex: 1,
    backgroundColor: '#FFC107',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 40,
  },
  brand: {
    fontSize: 40,
    fontWeight: '900',
    textTransform: 'uppercase',
    fontStyle: 'italic',
    letterSpacing: 1,
    textAlign: 'center',
    marginBottom: 8,
    textShadowOffset: { width: 1, height: 1 },
  },
  tagline: {
    fontSize: 16,
    fontStyle: 'italic',
    textAlign: 'center',
    color: '#333',
    marginBottom: 10,
  },
  burgerImage: {
    width: 280,
    height: 280,
    marginVertical: 10,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#000',
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#000',
    textAlign: 'center',
    marginBottom: 12,
  },
  description: {
    fontSize: 14,
    textAlign: 'center',
    color: '#333',
    marginBottom: 30,
    lineHeight: 20,
  },
  buttonRow: {
    flexDirection: 'row',
    gap: 15,
  },
  loginBtn: {
    borderWidth: 2,
    borderColor: '#000',
    borderRadius: 25,
    paddingVertical: 10,
    paddingHorizontal: 24,
    backgroundColor: '#FFC107',
  },
  signupBtn: {
    borderRadius: 25,
    paddingVertical: 10,
    paddingHorizontal: 24,
    backgroundColor: '#000',
  },
  loginText: {
    color: '#000',
    fontWeight: 'bold',
  },
  signupText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});
