import React, { useRef, useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  Image,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Dimensions,
} from 'react-native';
import { Ionicons, FontAwesome5 } from '@expo/vector-icons';

const { width: screenWidth } = Dimensions.get('window');

const galleryData = [
  {
    image: require('../assets/images/gallery1.jpg'),
    title: 'Crafted with Passion',
    description: 'At BurgaBliss, every burger is crafted with love, flavor, and fresh ingredients — just for you.',
    icon: 'utensils',
  },
  {
    image: require('../assets/images/gallery2.jpg'),
    title: 'Pakistan’s Favorite Burger',
    description: 'Our signature grilled beef burger is loved across generations — juicy, loaded, and unforgettable.',
    icon: 'hamburger',
  },
  {
    image: require('../assets/images/gallery3.jpg'),
    title: 'Cozy Dine-In Vibes',
    description: 'We bring together ambiance and taste, offering a perfect dine-in experience for families and friends.',
    icon: 'couch',
  },
  {
    image: require('../assets/images/gallery4.jpg'),
    title: 'Hospitality You Can Taste',
    description: 'It’s not just food, it’s warmth. Every burger is served with care, smiles, and satisfaction.',
    icon: 'smile',
  },
  {
    image: require('../assets/images/gallery5.jpg'),
    title: 'Spreading Across Pakistan',
    description: 'From one city to many — BurgaBliss is expanding to Lahore, Islamabad, Faisalabad, and beyond!',
    icon: 'map-marker-alt',
  },
];

const brandLogos = [
  require('../assets/images/brand-11.png'),
  require('../assets/images/brand-12.png'),
  require('../assets/images/brand-13.png'),
  require('../assets/images/brand-14.png'),
  require('../assets/images/brand-15.png'),
  require('../assets/images/brand-16.png'),
  require('../assets/images/brand-17.png'),
  require('../assets/images/brand-18.png'),
];

const GalleryScreen = () => {
  const scrollRef = useRef<ScrollView>(null);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const scrollX = useRef(new Animated.Value(0)).current;

  const handleScroll = (event: any) => {
    const offsetY = event.nativeEvent.contentOffset.y;
    setShowScrollTop(offsetY > 200);
  };

  const scrollToTop = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({ y: 0, animated: true });
    }
  };

  useEffect(() => {
    const animationDuration = 20000;

    Animated.loop(
      Animated.timing(scrollX, {
        toValue: -screenWidth,
        duration: animationDuration,
        useNativeDriver: true,
      })
    ).start();
  }, [scrollX]);

  return (
    <View style={styles.container}>
      <ScrollView
        ref={scrollRef}
        onScroll={handleScroll}
        scrollEventThrottle={16}
      >
        <Text style={styles.mainHeading}>Gallery & Brand Showcase</Text>
        <Text style={styles.subHeading}>
          Experience the journey of BurgaBliss — where great taste meets nationwide love.
        </Text>

        {/* Gallery Section */}
        <Text style={styles.sectionTitle}>Inside BurgaBliss</Text>
        {galleryData.map((item, index) => (
          <View key={index} style={styles.card}>
            <Image source={item.image} style={styles.galleryImage} />
            <View style={styles.iconRow}>
              <FontAwesome5 name={item.icon} size={20} color="#FF7043" style={styles.icon} />
              <Text style={styles.cardTitle}>{item.title}</Text>
            </View>
            <Text style={styles.cardText}>{item.description}</Text>
          </View>
        ))}

        {/* Brand Logos Section */}
        <Text style={styles.sectionTitle}>Our Trusted Brand Partners</Text>
        <View style={styles.brandScrollWrapper}>
          <Animated.View
            style={{
              flexDirection: 'row',
              transform: [{ translateX: scrollX }],
            }}
          >
            {[...brandLogos, ...brandLogos].map((logo, index) => (
              <Image key={index} source={logo} style={styles.brandLogo} />
            ))}
          </Animated.View>
        </View>

        {/* Closing Section */}
        <View style={styles.closingSection}>
          <Text style={styles.closingHeading}>Why Wait?</Text>
          <Text style={styles.closingText}>
            BurgaBliss is not just food — it is a promise of quality, freshness, and unforgettable flavor.
            Whether you&aposre in Karachi or soon in Lahore, Islamabad, or Multan — we are ready to serve you!
          </Text>
          <Text style={styles.closingCTA}>Order now and taste the difference.</Text>
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>

      {showScrollTop && (
        <TouchableOpacity style={styles.scrollTopButton} onPress={scrollToTop}>
          <Ionicons name="arrow-up" size={24} color="#fff" />
        </TouchableOpacity>
      )}
    </View>
  );
};

export default GalleryScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingTop: 50,
    paddingHorizontal: 16,
  },
  mainHeading: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#FF5722',
    textAlign: 'center',
    marginBottom: 6,
  },
  subHeading: {
    fontSize: 15,
    color: '#666',
    textAlign: 'center',
    marginBottom: 24,
    paddingHorizontal: 12,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#333',
    marginBottom: 16,
    marginTop: 10,
  },
  card: {
    marginBottom: 26,
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 14,
    shadowColor: '#000',
    shadowOpacity: 0.07,
    shadowOffset: { width: 0, height: 3 },
    shadowRadius: 6,
    elevation: 3,
  },
  galleryImage: {
    width: '100%',
    height: 200,
    borderRadius: 10,
    marginBottom: 10,
  },
  iconRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  icon: {
    marginRight: 8,
  },
  cardTitle: {
    fontSize: 17,
    fontWeight: '600',
    color: '#333',
  },
  cardText: {
    fontSize: 15,
    color: '#555',
    lineHeight: 22,
  },
  brandScrollWrapper: {
    overflow: 'hidden',
    width: '100%',
    height: 110,
    marginTop: 10,
    marginBottom: 40,
  },
  brandLogo: {
    width: 100,
    height: 100,
    resizeMode: 'contain',
    marginHorizontal: 10,
  },
  closingSection: {
    padding: 20,
    backgroundColor: '#FFF7E6',
    borderRadius: 12,
    marginBottom: 30,
  },
  closingHeading: {
    fontSize: 20,
    fontWeight: '700',
    color: '#FF7043',
    marginBottom: 10,
  },
  closingText: {
    fontSize: 15,
    color: '#333',
    lineHeight: 22,
    marginBottom: 12,
  },
  closingCTA: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FF5722',
    textAlign: 'center',
  },
  scrollTopButton: {
    position: 'absolute',
    bottom: 25,
    right: 25,
    backgroundColor: '#FFB300',
    padding: 12,
    borderRadius: 50,
    elevation: 5,
  },
});
