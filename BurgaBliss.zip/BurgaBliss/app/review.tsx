// app/review.tsx
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Modal,
  Alert,
} from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { auth, db } from '../firebase/config';
import { ref, onValue, push, set } from 'firebase/database';

interface Review {
  id: string;
  userEmail: string;
  rating: number;
  timestamp: string;
}

const ReviewScreen = () => {
  const router = useRouter();
  const { id } = useLocalSearchParams();
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [userRating, setUserRating] = useState(5);

  useEffect(() => {
    const reviewsRef = ref(db, `reviews/${id}`);
    const unsubscribe = onValue(reviewsRef, (snapshot) => {
      setLoading(true);
      if (snapshot.exists()) {
        const reviewsData = snapshot.val();
        const reviewsList = Object.keys(reviewsData).map(key => ({
          id: key,
          ...reviewsData[key]
        }));
        setReviews(reviewsList.sort((a, b) => 
          new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
        ));
      } else {
        setReviews([]);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [id]);

  const updateBurgerRating = async (newRating: number) => {
    try {
      // Update burger's rating
      const totalRating = reviews.reduce((sum, review) => sum + review.rating, 0) + newRating;
      const averageRating = ((totalRating) / (reviews.length + 1)).toFixed(1);
      await set(ref(db, `burgers/${id}/rating`), Number(averageRating));
    } catch (error) {
      console.error('Error updating burger rating:', error);
    }
  };

  const handleSubmitReview = async () => {
    const user = auth.currentUser;
    if (!user) {
      Alert.alert('Please login first');
      return;
    }

    try {
      const reviewsRef = ref(db, `reviews/${id}`);
      const newReviewRef = push(reviewsRef);
      await set(newReviewRef, {
        userEmail: user.email,
        rating: userRating,
        timestamp: new Date().getTime()  // Use Unix timestamp for Firebase
      });

      // Update the burger's average rating
      await updateBurgerRating(userRating);

      setUserRating(5);
      setShowReviewModal(false);
      Alert.alert('Success', 'Your rating has been submitted!');
    } catch (error) {
      console.error('Error submitting rating:', error);
      Alert.alert('Error', 'Could not submit rating. Please try again.');
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#fff' }}>
      <ScrollView contentContainerStyle={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()}>
            <Ionicons name="arrow-back" size={24} color="#333" />
          </TouchableOpacity>
          <Text style={styles.title}>Reviews</Text>
          <TouchableOpacity 
            onPress={() => setShowReviewModal(true)}
            style={styles.addReviewButton}
          >
            <Ionicons name="add" size={24} color="#fff" />
          </TouchableOpacity>
        </View>

        {/* Review List */}
        {loading ? (
          <ActivityIndicator size="large" color="#F86F03" style={{ marginTop: 20 }} />
        ) : reviews.length > 0 ? (
          reviews.map((review) => (
            <View key={review.id} style={styles.reviewCard}>
              <View style={styles.reviewCard}>
                <Text style={styles.user}>{review.userEmail}</Text>
                <View style={styles.stars}>
                  {[...Array(5)].map((_, idx) => (
                    <Ionicons
                      key={idx}
                      name="star"
                      size={16}
                      color={idx < review.rating ? '#FFC107' : '#ddd'}
                    />
                  ))}
                </View>
                <Text style={styles.timestamp}>
                  {new Date(review.timestamp).toLocaleDateString()}
                </Text>
              </View>
            </View>
          ))
        ) : (
          <Text style={styles.noReviews}>No reviews found for this burger.</Text>
        )}
      </ScrollView>

      {/* Review Modal */}
      <Modal
        visible={showReviewModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowReviewModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <TouchableOpacity 
              style={styles.closeButton}
              onPress={() => setShowReviewModal(false)}
            >
              <Ionicons name="close" size={24} color="#666" />
            </TouchableOpacity>

            <Text style={styles.modalTitle}>Write a Review</Text>
            
            <View style={styles.ratingPicker}>
              {[1, 2, 3, 4, 5].map((rating) => (
                <TouchableOpacity
                  key={rating}
                  onPress={() => setUserRating(rating)}
                >
                  <Ionicons
                    name="star"
                    size={36}
                    color={rating <= userRating ? '#FFC107' : '#ddd'}
                  />
                </TouchableOpacity>
              ))}
            </View>

            <Text style={styles.ratingText}>
              Your rating: {userRating} {userRating === 1 ? 'star' : 'stars'}
            </Text>

            <TouchableOpacity 
              style={styles.submitButton}
              onPress={handleSubmitReview}
            >
              <Text style={styles.submitButtonText}>Submit Rating</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
};

export default ReviewScreen;

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#fff',
  },
  header: {
    marginTop: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  reviewCard: {
    padding: 15,
    backgroundColor: '#f8f8f8',
    borderRadius: 8,
    marginBottom: 15,
  },
  user: {
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 4,
  },
  rating: {
    fontSize: 14,
    color: '#FFA726',
    marginBottom: 4,
  },
  comment: {
    fontSize: 14,
    color: '#333',
    marginVertical: 8,
  },
  noReviews: {
    fontSize: 16,
    textAlign: 'center',
    marginTop: 30,
    color: '#777',
  },
  addReviewButton: {
    backgroundColor: '#F86F03',
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  reviewHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  stars: {
    flexDirection: 'row',
    gap: 2,
  },
  timestamp: {
    fontSize: 12,
    color: '#999',
    marginTop: 4,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 20,
    width: '100%',
    maxWidth: 400,
  },
  closeButton: {
    alignSelf: 'flex-end',
    padding: 8,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
  },
  ratingPicker: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 20,
    gap: 8,
  },
  reviewInput: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    height: 120,
    textAlignVertical: 'top',
    marginBottom: 20,
  },
  submitButton: {
    backgroundColor: '#F86F03',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  submitButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  ratingText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 20,
  },
});
