import React, { useState, useEffect } from 'react';
import {
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Linking,
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import { MotiView, MotiText } from 'moti';
import { useIsFocused } from '@react-navigation/native';

const ContactInfoScreen = () => {
  const phoneNumber = '+9230034567';
  const emailAddress = 'burgabliss@gmail.com';
  const isFocused = useIsFocused();
  const [visible, setVisible] = useState(false);

  const openDialer = () => Linking.openURL(`tel:${phoneNumber}`);
  const openEmail = () => Linking.openURL(`mailto:${emailAddress}`);
  const openMaps = () =>
    Linking.openURL(
      `https://www.google.com/maps/search/?api=1&query=Burger+Street+Gujranwala`
    );

  useEffect(() => {
    if (isFocused) {
      setVisible(false);
      setTimeout(() => setVisible(true), 50);
    }
  }, [isFocused]);

  return (
    <ScrollView style={styles.container}>
      {visible && (
        <>
          <MotiText
            from={{ opacity: 0, translateY: -20 }}
            animate={{ opacity: 1, translateY: 0 }}
            transition={{ type: 'timing', duration: 600 }}
            style={styles.header}
          >
            Get in Touch with <Text style={styles.orange}>BurgaBliss!</Text>
          </MotiText>

          <MotiView
            from={{ opacity: 0, translateY: 40 }}
            animate={{ opacity: 1, translateY: 0 }}
            transition={{ delay: 100, duration: 500 }}
            style={styles.section}
          >
            <View style={styles.sectionHeader}>
              <Icon name="map-marker" size={24} color="#E74C3C" style={styles.icon} />
              <Text style={styles.sectionTitle}>Address</Text>
            </View>
            <Text style={styles.detailText}>BurgaBliss Main Branch,</Text>
            <Text style={styles.detailText}>123 Burger Street, Garden Town,</Text>
            <Text style={styles.detailText}>Gujranwala, Punjab, Pakistan.</Text>
            <TouchableOpacity style={styles.contactRow} onPress={openMaps}>
              <Icon name="location-arrow" size={18} color="#555" style={styles.contactIcon} />
              <Text style={styles.contactText}>Open in Maps</Text>
            </TouchableOpacity>
          </MotiView>

          <MotiView
            from={{ opacity: 0, translateY: 40 }}
            animate={{ opacity: 1, translateY: 0 }}
            transition={{ delay: 200, duration: 500 }}
            style={styles.section}
          >
            <View style={styles.sectionHeader}>
              <Icon name="clock-o" size={24} color="#F39C12" style={styles.icon} />
              <Text style={styles.sectionTitle}>Working Hours</Text>
            </View>
            <Text style={styles.detailText}>Mon - Fri: 11:00 AM - 11:00 PM</Text>
            <Text style={styles.detailText}>Sat - Sun: 12:00 PM - 12:00 AM</Text>
          </MotiView>

          <MotiView
            from={{ opacity: 0, translateY: 40 }}
            animate={{ opacity: 1, translateY: 0 }}
            transition={{ delay: 300, duration: 500 }}
            style={styles.section}
          >
            <View style={styles.sectionHeader}>
              <Icon name="phone" size={24} color="#2ECC71" style={styles.icon} />
              <Text style={styles.sectionTitle}>Contact Us</Text>
            </View>
            <TouchableOpacity style={styles.contactRow} onPress={openDialer}>
              <Icon name="phone" size={18} color="#555" style={styles.contactIcon} />
              <Text style={styles.contactText}>{phoneNumber}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.contactRow} onPress={openEmail}>
              <Icon name="envelope" size={18} color="#555" style={styles.contactIcon} />
              <Text style={styles.contactText}>{emailAddress}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.contactRow}>
              <Icon name="globe" size={18} color="#555" style={styles.contactIcon} />
              <Text style={styles.contactText}>www.burgabliss.com</Text>
            </TouchableOpacity>
          </MotiView>
        </>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
    padding: 20,
  },
  header: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 25,
    marginTop: 10,
  },
  orange: {
    color: '#E67E22',
  },
  section: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 15,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
    paddingBottom: 10,
  },
  icon: {
    marginRight: 10,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#444',
  },
  detailText: {
    fontSize: 16,
    lineHeight: 24,
    color: '#666',
    marginBottom: 5,
    paddingLeft: 34,
  },
  contactRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingLeft: 34,
  },
  contactIcon: {
    marginRight: 10,
    width: 20,
    textAlign: 'center',
  },
  contactText: {
    fontSize: 16,
    color: '#555',
  },
});

export default ContactInfoScreen;
