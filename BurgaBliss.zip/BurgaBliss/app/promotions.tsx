import React, { useState, useEffect } from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { MotiView } from 'moti';

const { width } = Dimensions.get('window');

const promotionalOffers = [
  {
    id: '1',
    title: 'Weekend Burger Bonanza!',
    description: 'Buy any burger, get 50% off on your second burger!',
    image: require('../assets/images/Weekend.jpg'),
    validity: 'Valid July 5–10, 2025',
  },
  {
    id: '2',
    title: 'Family Feast Deal',
    description: '2 Burgers + 2 Fries + 2 Drinks for only PKR 1299!',
    image: require('../assets/images/familydeal.avif'),
    validity: 'July 10–13, 2025',
  },
  {
    id: '3',
    title: 'Student Discount',
    description: 'Show your student ID and get 10% off your entire order.',
    image: require('../assets/images/student.jpg'),
    validity: 'Monday–Thursday',
  },
  {
    id: '4',
    title: 'Free Delivery Friday!',
    description: 'Enjoy free delivery on orders over PKR 500 every Friday.',
    image: require('../assets/images/freedelivery.jpg'),
    validity: 'Every Friday in July',
  },
];

const PromotionsScreen = () => {
  const [visibleItems, setVisibleItems] = useState<string[]>([]);

  useEffect(() => {
    const timeoutIds = promotionalOffers.map((item, index) =>
      setTimeout(() => {
        setVisibleItems((prev) => [...prev, item.id]);
      }, 300 * index)
    );

    return () => timeoutIds.forEach(clearTimeout);
  }, []);

  const renderPromotionItem = ({ item }: { item: any }) => {
    if (!visibleItems.includes(item.id)) return null;

    return (
      <MotiView
        from={{ opacity: 0, translateY: 30 }}
        animate={{ opacity: 1, translateY: 0 }}
        transition={{ type: 'timing', duration: 500 }}
        style={styles.promotionCard}
      >
        <Image source={item.image} style={styles.promotionImage} />
        <View style={styles.textContainer}>
          <Text style={styles.promoTitle}>{item.title}</Text>
          <Text style={styles.promoDescription}>{item.description}</Text>
          <Text style={styles.promoValidity}>{item.validity}</Text>
        </View>
      </MotiView>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Exclusive Deals & Offers</Text>
      <FlatList
        data={promotionalOffers}
        renderItem={renderPromotionItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fefefe',
    padding: 12,
  },
  header: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#FF5722',
    textAlign: 'center',
    marginBottom: 20,
    marginTop: 30,
  },
  listContent: {
    paddingBottom: 30,
  },
  promotionCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 18,
    marginHorizontal: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 5,
  },
  promotionImage: {
    width: '100%',
    height: width * 0.5,
    resizeMode: 'cover',
  },
  textContainer: {
    padding: 15,
  },
  promoTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 8,
  },
  promoDescription: {
    fontSize: 16,
    color: '#555',
    marginBottom: 10,
    lineHeight: 22,
  },
  promoValidity: {
    fontSize: 14,
    color: '#E74C3C',
    fontWeight: '600',
    fontStyle: 'italic',
  },
});

export default PromotionsScreen;
