import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { View, Text } from 'react-native';
import useCartCount from '../../hooks/useCartCount'; // ✅ adjust path if needed

import HomeScreen from './home';
import CartScreen from './cart';
import FavoritesScreen from './favorites';
import AboutUsScreen from './about';
import ProfileScreen from './profile';

const Tab = createBottomTabNavigator();

export default function TabsLayout() {
  const cartCount = useCartCount(); // ✅ Live cart count from Realtime DB

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: '#FFC107',
        tabBarInactiveTintColor: 'gray',
        tabBarIcon: ({ focused, color, size }) => {
          let iconName = 'home';
          if (route.name === 'home') iconName = focused ? 'home' : 'home-outline';
          else if (route.name === 'cart') iconName = focused ? 'cart' : 'cart-outline';
          else if (route.name === 'favorites') iconName = focused ? 'heart' : 'heart-outline';
          else if (route.name === 'about') iconName = focused ? 'information-circle' : 'information-circle-outline';
          else if (route.name === 'profile') iconName = focused ? 'person-circle' : 'person-circle-outline';

          // ✅ Cart badge icon logic
          if (route.name === 'cart') {
            return (
              <View style={{ position: 'relative' }}>
                <Ionicons name={iconName as any} size={size} color={color} />
                {cartCount > 0 && (
                  <View
                    style={{
                      position: 'absolute',
                      top: -4,
                      right: -6,
                      backgroundColor: '#FF3D00',
                      borderRadius: 10,
                      paddingHorizontal: 5,
                      paddingVertical: 1,
                      minWidth: 18,
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    <Text style={{ color: '#fff', fontSize: 10, fontWeight: 'bold' }}>
                      {cartCount}
                    </Text>
                  </View>
                )}
              </View>
            );
          }

          return <Ionicons name={iconName as any} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="home" component={HomeScreen} options={{ title: 'Home' }} />
      <Tab.Screen name="cart" component={CartScreen} options={{ title: 'Cart' }} />
      <Tab.Screen name="favorites" component={FavoritesScreen} options={{ title: 'Favorites' }} />
      <Tab.Screen name="about" component={AboutUsScreen} options={{ title: 'About' }} />
      <Tab.Screen name="profile" component={ProfileScreen} options={{ title: 'Profile' }} />
    </Tab.Navigator>
  );
}
