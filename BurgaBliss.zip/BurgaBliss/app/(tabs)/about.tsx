import React, { useState, useEffect } from 'react';
import { ScrollView, StyleSheet, Text, View, Image, TouchableOpacity } from 'react-native';
import { MotiView, MotiText } from 'moti';
import { useIsFocused } from '@react-navigation/native';
import { useRouter } from 'expo-router';

const AboutUsScreen: React.FC = () => {
  const router = useRouter();
  const isFocused = useIsFocused();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (isFocused) {
      setVisible(false);
      setTimeout(() => setVisible(true), 50);
    }
  }, [isFocused]);

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
      <View style={styles.spacer} />

      {visible && (
        <>
          <MotiView
            from={{ opacity: 0, translateY: 50 }}
            animate={{ opacity: 1, translateY: 0 }}
            transition={{ type: 'timing', duration: 1000 }}
          >
            <Image
              source={require('../../assets/images/about-banner.png')}
              style={styles.headerImage}
              resizeMode="contain"
            />
          </MotiView>

          <MotiText
            from={{ opacity: 0, translateY: 20 }}
            animate={{ opacity: 1, translateY: 0 }}
            transition={{ type: 'timing', duration: 800, delay: 300 }}
            style={styles.title}
          >
            Welcome to <Text style={styles.highlight}>BurgaBliss!</Text>
          </MotiText>
        </>
      )}

      <Text style={styles.description}>
        At <Text style={styles.highlight}>BurgaBliss</Text>, we believe in crafting the
        <Text style={styles.bold}> perfect burger experience</Text>. Our journey began with a simple passion:
        to serve <Text style={styles.bold}>delicious, high-quality burgers</Text> made from the
        <Text style={styles.bold}> freshest ingredients</Text>.
      </Text>

      <Text style={styles.description}>
        From our <Text style={styles.bold}>juicy patties</Text> to our <Text style={styles.bold}>freshly baked buns</Text> and
        <Text style={styles.bold}> secret sauces</Text>, every element is chosen with care to ensure a
        <Text style={styles.highlight}> blissful bite</Text> every time.
      </Text>

      <Text style={styles.subtitle}>Our Mission</Text>
      <Text style={styles.description}>
        To bring <Text style={styles.bold}>joy</Text> and <Text style={styles.bold}>satisfaction</Text> through
        <Text style={styles.highlight}> exceptional burgers</Text> and
        <Text style={styles.highlight}> outstanding customer service</Text>.
      </Text>

      {/* Navigation Buttons */}
      <TouchableOpacity style={styles.button} onPress={() => router.push('/contact')}>
        <Text style={styles.buttonText}>Contact Us</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.button} onPress={() => router.push('/promotions')}>
        <Text style={styles.buttonText}>Explore Deals</Text>
      </TouchableOpacity>

      {/* Gallery & Brand Partners Button */}
      <TouchableOpacity
        style={styles.galleryButton}
        onPress={() => router.push('/gallery')}
      >
        <Text style={styles.galleryButtonText}>Explore Gallery & Brand Partners</Text>
      </TouchableOpacity>

      <Text style={styles.subtitle}>Our Values</Text>
      <Text style={styles.description}>
        <Text style={styles.value}>Quality</Text>, <Text style={styles.value}>Freshness</Text>,
        <Text style={styles.value}> Customer Satisfaction</Text>, <Text style={styles.value}>Community</Text>.
      </Text>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f8f8' },
  contentContainer: { padding: 20 },
  spacer: { height: 70 },
  headerImage: {
    width: '100%',
    height: 220,
    marginBottom: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 15,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 22,
    fontWeight: '600',
    color: '#555',
    marginTop: 20,
    marginBottom: 10,
  },
  description: {
    fontSize: 16,
    lineHeight: 24,
    color: '#666',
    marginBottom: 10,
  },
  highlight: {
    color: '#FF5722',
    fontWeight: 'bold',
  },
  bold: {
    fontWeight: '600',
    color: '#444',
  },
  value: {
    fontWeight: 'bold',
    color: '#FF5722',
  },
  button: {
    backgroundColor: '#FF7043',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
    alignSelf: 'center',
    marginTop: 20,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  galleryButton: {
    backgroundColor: '#FF7043',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 30,
  },
  galleryButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});

export default AboutUsScreen;
