import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { AntDesign, Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { auth, db } from '../../firebase/config';
import { ref, set, onValue, get } from 'firebase/database';

interface CartItem {
  id: string;
  name: string;
  image: string;
  price: number;
  quantity: number;
}

const DISCOUNT_CODE = 'zarish@12';
const DISCOUNT_AMOUNT = 200;

const CartScreen = () => {
  const router = useRouter();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [discountCode, setDiscountCode] = useState('');
  const [discountApplied, setDiscountApplied] = useState(false);

  useEffect(() => {
    let unsubscribe: () => void;
    let authUnsubscribe: () => void;

    const setupCartListener = async () => {
      setLoading(true);
      
      // Set up auth state listener
      authUnsubscribe = auth.onAuthStateChanged((user) => {
        if (!user) {
          setCartItems([]);
          setLoading(false);
          if (unsubscribe) {
            unsubscribe();
          }
          router.replace('/login');
          return;
        }
      });

      // Check if user is authenticated
      const user = auth.currentUser;
      if (!user) {
        setLoading(false);
        router.replace('/login');
        return;
      }

      try {
        const cartRef = ref(db, `users/${user.uid}/cart`);
        
        // Set up real-time listener for cart changes
        const onCartUpdate = (snapshot: any) => {
          if (snapshot.exists()) {
            const items: CartItem[] = [];
            snapshot.forEach((childSnapshot: any) => {
              const item = childSnapshot.val();
              if (item) {
                items.push({
                  id: childSnapshot.key,
                  ...item
                });
              }
            });
            setCartItems(items);
          } else {
            setCartItems([]);
          }
          setLoading(false);
        };

        // Handle errors in the listener
        const onError = (error: any) => {
          console.error('Error fetching cart items:', error);
          // Silently handle permission denied errors as they're expected during logout
          if (error.message?.includes('permission_denied')) {
            setCartItems([]);
          } else {
            // Handle other types of errors
            Alert.alert(
              'Error',
              'There was an error accessing your cart data.'
            );
          }
          setLoading(false);
        };

        // Set up the listener
        unsubscribe = onValue(cartRef, onCartUpdate, onError);
      } catch (error) {
        console.error('Error setting up cart listener:', error);
        setLoading(false);
      }
    };

    setupCartListener();

    // Cleanup listeners when component unmounts
    return () => {
      if (unsubscribe) {
        unsubscribe();
      }
      if (authUnsubscribe) {
        authUnsubscribe();
      }
    };
  }, [router]);

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = cartItems.length > 0 ? 200 : 0;
  const total = subtotal + shipping;

  const handleUpdateQuantity = async (index: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    
    const user = auth.currentUser;
    if (!user) return;

    const item = cartItems[index];
    const cartRef = ref(db, `users/${user.uid}/cart/${item.id}`);
    
    try {
      await set(cartRef, {
        ...item,
        quantity: newQuantity
      });

      const updatedItems = [...cartItems];
      updatedItems[index] = { ...item, quantity: newQuantity };
      setCartItems(updatedItems);
    } catch (error) {
      console.error('Error updating quantity:', error);
    }
  };

  const handleDeleteItem = async (index: number) => {
    const user = auth.currentUser;
    if (!user) return;

    const item = cartItems[index];
    const cartRef = ref(db, `users/${user.uid}/cart/${item.id}`);
    
    try {
      await set(cartRef, null); // Remove from Firebase
      const updatedItems = cartItems.filter((_, i) => i !== index);
      setCartItems(updatedItems);
    } catch (error) {
      console.error('Error deleting item:', error);
    }
  };

  const handleIncrement = (index: number) => {
    const item = cartItems[index];
    handleUpdateQuantity(index, item.quantity + 1);
  };

  const handleDecrement = (index: number) => {
    const item = cartItems[index];
    if (item.quantity > 1) {
      handleUpdateQuantity(index, item.quantity - 1);
    }
  };

  const handleDiscountCode = () => {
    if (discountCode === DISCOUNT_CODE && !discountApplied) {
      setDiscountApplied(true);
    }
  };



  const handlePayNow = async () => {
    const user = auth.currentUser;
    if (!user) {
      Alert.alert('Please login first');
      return;
    }

    if (cartItems.length === 0) {
      Alert.alert('Cart Empty', 'Please add items to your cart before checking out.');
      return;
    }

    setIsProcessingPayment(true);
    try {
      // Create a new order in Firebase
      const orderId = `ORD${Date.now()}`; // More readable order ID
      const orderRef = ref(db, `users/${user.uid}/orders/${orderId}`);
      
      const orderData = {
        items: cartItems,
        subtotal,
        shipping,
        discount: discountApplied ? DISCOUNT_AMOUNT : 0,
        total: total - (discountApplied ? DISCOUNT_AMOUNT : 0),
        status: 'pending',
        paymentStatus: 'completed', // Assuming COD or payment is always successful
        timestamp: new Date().toISOString(),
        orderId,
        timeline: [
          {
            status: 'order_placed',
            timestamp: new Date().toISOString(),
            message: 'Order has been placed successfully'
          }
        ]
      };

      // Save order to Firebase under user's orders
      await set(orderRef, orderData);

      // Save to general orders collection for admin
      const adminOrderRef = ref(db, `orders/${orderId}`);
      await set(adminOrderRef, {
        ...orderData,
        userId: user.uid,
        userEmail: user.email,
        userName: user.displayName || 'Guest'
      });

      // Update order count in user's profile
      const userOrderCountRef = ref(db, `users/${user.uid}/orderCount`);
      const orderCountSnapshot = await get(userOrderCountRef);
      const currentCount = orderCountSnapshot.exists() ? orderCountSnapshot.val() : 0;
      await set(userOrderCountRef, currentCount + 1);

      // Clear the user's cart
      const cartRef = ref(db, `users/${user.uid}/cart`);
      await set(cartRef, null);

      // Navigate to success screen with order details
      router.push({
        pathname: '/order-success',
        params: { orderId }
      });
    } catch (error: any) {
      console.error('Payment error:', error);
      let errorMessage = 'There was an error processing your payment. Please try again.';
      
      if (error.message?.includes('PERMISSION_DENIED')) {
        errorMessage = 'Permission denied. Please log out and log in again.';
      }

      Alert.alert(
        'Payment Failed',
        errorMessage
      );
    } finally {
      setIsProcessingPayment(false);
    }
  };

  if (loading) {
    return (
      <View style={[styles.container, styles.center]}>
        <ActivityIndicator size="large" color="#FFA726" />
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={{ paddingTop: 15 }}>
          <Ionicons name="arrow-back" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Your Cart</Text>
        <View style={{ width: 24, paddingTop: 15 }} />
      </View>

      {/* Cart Items */}
      {cartItems.length === 0 ? (
        <View style={styles.emptyCart}>
          <Text style={styles.emptyText}>Your cart is empty</Text>
        </View>
      ) : (
        cartItems.map((item, index) => (
          <View key={item.id} style={styles.card}>
            <Image source={{ uri: item.image }} style={styles.image} />
            <View style={styles.info}>
              <Text style={styles.title}>{item.name}</Text>
              <Text style={styles.price}>PKR {item.price}</Text>
            </View>
            <View style={styles.rightControls}>
              <View style={styles.quantityControl}>
                <TouchableOpacity onPress={() => handleDecrement(index)}>
                  <AntDesign name="minus" size={20} color="#000" />
                </TouchableOpacity>
                <Text style={styles.quantity}>{item.quantity}</Text>
                <TouchableOpacity onPress={() => handleIncrement(index)}>
                  <AntDesign name="plus" size={20} color="#000" />
                </TouchableOpacity>
              </View>
              <TouchableOpacity 
                onPress={() => handleDeleteItem(index)}
                style={styles.deleteButton}
              >
                <AntDesign name="delete" size={20} color="#FF3B30" />
              </TouchableOpacity>
            </View>
          </View>
        ))
      )}

      {/* Discount Section */}
      <View style={styles.discountContainer}>
        <AntDesign name="tagso" size={18} color="#F39C12" />
        <TextInput
          placeholder="Enter your discount code"
          placeholderTextColor="#999"
          style={styles.discountInput}
          value={discountCode}
          onChangeText={setDiscountCode}
        />
        <TouchableOpacity 
          style={[styles.applyButton, discountApplied && styles.appliedButton]} 
          onPress={handleDiscountCode}
          disabled={discountApplied}
        >
          <Text style={styles.applyButtonText}>
            {discountApplied ? 'Applied' : 'Apply'}
          </Text>
        </TouchableOpacity>
      </View>

      {/* Cost Breakdown */}
      <View style={styles.breakdown}>
        <View style={styles.row}>
          <Text style={styles.label}>Sub total</Text>
          <Text style={styles.value}>PKR {subtotal}</Text>
        </View>
        <View style={styles.row}>
          <Text style={styles.label}>Shipping</Text>
          <Text style={styles.value}>PKR {shipping}</Text>
        </View>
        <View style={styles.row}>
          <Text style={styles.label}>Discount</Text>
          <Text style={styles.value}>
            PKR {discountApplied ? DISCOUNT_AMOUNT : '-'}
          </Text>
        </View>
        <View style={styles.row}>
          <Text style={styles.totalLabel}>Total</Text>
          <Text style={styles.totalValue}>
            PKR {total - (discountApplied ? DISCOUNT_AMOUNT : 0)}
          </Text>
        </View>
      </View>

      {/* Pay Button */}
      <TouchableOpacity 
        style={[styles.payButton, isProcessingPayment && styles.payButtonDisabled]}
        onPress={handlePayNow}
        disabled={isProcessingPayment}
      >
        {isProcessingPayment ? (
          <ActivityIndicator color="#fff" size="small" />
        ) : (
          <Text style={styles.payText}>Pay now</Text>
        )}
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#fff',
    flexGrow: 1,
  },
  rightControls: {
    alignItems: 'center',
    gap: 10,
  },
  deleteButton: {
    padding: 8,
  },
  applyButton: {
    backgroundColor: '#FFA726',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 6,
    marginLeft: 10,
  },
  appliedButton: {
    backgroundColor: '#4CAF50',
  },
  applyButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  center: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyCart: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 50,
  },
  emptyText: {
    fontSize: 18,
    color: '#666',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 25,
    paddingHorizontal: 5,
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 15,
  },
  card: {
    flexDirection: 'row',
    backgroundColor: '#f9f9f9',
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    alignItems: 'center',
  },
  image: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 15,
  },
  info: {
    flex: 1,
  },
  title: {
    color: '#FFA726',
    fontSize: 12,
    fontWeight: 'bold',
  },
  subtitle: {
    fontSize: 14,
    color: '#333',
  },
  price: {
    marginTop: 5,
    fontSize: 14,
    fontWeight: 'bold',
  },
  quantityControl: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  quantity: {
    fontSize: 16,
    fontWeight: 'bold',
    marginHorizontal: 8,
  },
  discountContainer: {
    borderStyle: 'dashed',
    borderColor: '#FFA726',
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 20,
  },
  discountInput: {
    marginLeft: 10,
    flex: 1,
    color: '#333',
  },
  breakdown: {
    marginBottom: 30,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  label: {
    fontSize: 16,
    color: '#333',
  },
  value: {
    fontSize: 16,
    color: '#333',
  },
  totalLabel: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  totalValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFA726',
  },
  payButton: {
    backgroundColor: '#000',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },
  payText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  payButtonDisabled: {
    backgroundColor: '#666',
    opacity: 0.7,
  },
});

export default CartScreen;