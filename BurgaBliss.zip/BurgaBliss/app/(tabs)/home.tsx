import React, { useState, useCallback, useRef, useEffect } from 'react';
import { useRouter } from 'expo-router';
import { 
  View, 
  Text, 
  TextInput, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  Image, 
  ActivityIndicator,
} from 'react-native';
import { db, auth } from '../../firebase/config';
import { ref, set, remove, onValue } from 'firebase/database';
import { Ionicons, FontAwesome } from '@expo/vector-icons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';

const categories = ['All', 'Beef', 'Cheese', 'Shrimp', 'Chicken'];

export default function HomeScreen() {
  const router = useRouter();
  const scrollRef = useRef<ScrollView>(null);
  const navigation = useNavigation<BottomTabNavigationProp<any>>();
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [favorites, setFavorites] = useState<string[]>([]);
  const [burgers, setBurgers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const burgersRef = ref(db, 'burgers');
    onValue(burgersRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const loadedBurgers = Object.keys(data).map((key) => ({
          id: key,
          ...data[key],
        }));
        setBurgers(loadedBurgers);
      } else {
        setBurgers([]);
      }
      setLoading(false);
    });
  }, []);

  // 🔁 Load favorite IDs
  useEffect(() => {
    const user = auth.currentUser;
    if (!user) return;

    const favRef = ref(db, `users/${user.uid}/favorites`);

    const unsubscribe = onValue(favRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const favIds = Object.keys(data);
        setFavorites(favIds);
      } else {
        setFavorites([]);
      }
    });

    return () => unsubscribe();
  }, []);

  // ❤️ Toggle Favorite
  const toggleFavorite = async (burger: any) => {
    const user = auth.currentUser;
    if (!user) return;

    const favRef = ref(db, `users/${user.uid}/favorites/${burger.id}`);

    try {
      if (favorites.includes(burger.id)) {
        await remove(favRef);
        setFavorites((prev) => prev.filter((id) => id !== burger.id));
      } else {
        await set(favRef, {
          id: burger.id,
          name: burger.name,
          image: burger.imageUrl || burger.image || '',
          rating: burger.rating,
          price: burger.price,
          timestamp: new Date().toISOString(),
        });
        setFavorites((prev) => [...prev, burger.id]);
      }
    } catch (err) {
      console.log('Error updating favorites:', err);
    }
  };

  const filteredBurgers = burgers.filter((b) => {
    
    // Category filtering - make it case insensitive and more flexible
    const matchesCategory = selectedCategory === 'All' 
      ? true 
      : b.category?.toLowerCase().includes(selectedCategory.toLowerCase()) || 
        b.name.toLowerCase().includes(selectedCategory.toLowerCase());
    
    // Search filtering - search in name and description
    const searchLower = searchQuery.trim().toLowerCase();
    const matchesSearch = searchLower === '' 
      ? true 
      : b.name.toLowerCase().includes(searchLower) ||
        (b.description || '').toLowerCase().includes(searchLower) ||
        (b.category || '').toLowerCase().includes(searchLower);

    return matchesCategory && matchesSearch;
  });

  useFocusEffect(
    useCallback(() => {
      const unsubscribe = navigation.addListener('tabPress', () => {
        // Reset to top of screen
        scrollRef.current?.scrollTo({ y: 0, animated: true });
        // Clear search query
        setSearchQuery('');
        // Reset category to All
        setSelectedCategory('All');
      });
      return unsubscribe;
    }, [navigation])
  );

  return (
    <ScrollView style={styles.container} ref={scrollRef}>
      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <Ionicons name="search" size={20} color="#888" />
        <TextInput
          placeholder="Find your burger"
          placeholderTextColor="#888"
          style={styles.searchInput}
          value={searchQuery}
          onChangeText={setSearchQuery}
          returnKeyType="search"
          autoCapitalize="none"
        />
        {searchQuery ? (
          <TouchableOpacity onPress={() => setSearchQuery('')}>
            <Ionicons name="close-circle" size={20} color="#888" />
          </TouchableOpacity>
        ) : (
          <Ionicons name="filter" size={20} color="#888" />
        )}
      </View>

      {/* Headings */}
      <Text style={styles.heading}>Find and order</Text>
      <Text style={styles.subheading}>
        <Text style={{ fontWeight: 'bold' }}>burger for you </Text>🍔
      </Text>

      {/* Category Filter */}
      <View style={styles.categories}>
        {categories.map((category) => (
          <TouchableOpacity
            key={category}
            onPress={() => {
              setSelectedCategory(category);
              // Clear search when selecting "All"
              if (category === 'All') {
                setSearchQuery('');
              }
            }}
            style={[
              styles.categoryBtn,
              selectedCategory === category && styles.activeCategory,
            ]}
          >
            <Text
              style={[
                styles.categoryText,
                selectedCategory === category && styles.activeCategoryText,
              ]}
            >
              {category}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Section Title */}
      <Text style={styles.sectionTitle}>Most popular</Text>

      {/* Loader */}
      {loading ? (
        <ActivityIndicator size="large" color="#FFC107" style={{ marginTop: 40 }} />
      ) : (
        <View style={styles.burgerGrid}>
          {filteredBurgers.map((burger) => (
            <TouchableOpacity
              key={burger.id}
              style={styles.burgerCard}
              onPress={() =>
                router.push({
                  pathname: '/burger-details/[id]',
                  params: { id: burger.id },
                })
              }
            >
              <Image source={{ uri: burger.imageUrl || burger.image }} style={styles.burgerImage} />

              <TouchableOpacity
                style={styles.favoriteIcon}
                onPress={() => toggleFavorite(burger)}
              >
                <FontAwesome
                  name={favorites.includes(burger.id) ? 'heart' : 'heart-o'}
                  size={18}
                  color={favorites.includes(burger.id) ? 'red' : '#888'}
                />
              </TouchableOpacity>

              <Text style={styles.burgerName}>{burger.name}</Text>

              <View style={styles.ratingRow}>
                <Ionicons name="star" size={14} color="#FFC107" />
                <Text style={styles.ratingText}>{burger.rating}</Text>
              </View>
              <Text style={styles.price}>PKR {burger.price}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: '#fff',
  },
  searchContainer: {
    flexDirection: 'row',
    backgroundColor: '#eee',
    padding: 10,
    borderRadius: 25,
    alignItems: 'center',
    marginBottom: 18,
    marginTop: 20,
  },
  searchInput: {
    flex: 1,
    paddingHorizontal: 10,
    color: '#000',
  },
  heading: {
    fontSize: 18,
    color: '#222',
  },
  subheading: {
    fontSize: 24,
    marginBottom: 14,
    color: '#000',
  },
  categories: {
    flexDirection: 'row',
    marginBottom: 20,
    gap: 10,
  },
  categoryBtn: {
    backgroundColor: '#eee',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
  },
  activeCategory: {
    backgroundColor: '#FFC107',
  },
  categoryText: {
    color: '#444',
  },
  activeCategoryText: {
    color: '#000',
    fontWeight: 'bold',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 10,
  },
  burgerGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  burgerCard: {
    width: '48%',
    backgroundColor: '#f8f8f8',
    borderRadius: 16,
    marginBottom: 20,
    padding: 10,
    position: 'relative',
  },
  burgerImage: {
    width: '100%',
    height: 100,
    resizeMode: 'cover',
    borderRadius: 10,
  },
  favoriteIcon: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 4,
    elevation: 2,
  },
  burgerName: {
    fontWeight: '600',
    fontSize: 14,
    marginTop: 8,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 4,
  },
  ratingText: {
    fontSize: 12,
    color: '#555',
  },
  price: {
    fontWeight: 'bold',
    color: '#FFC107',
    fontSize: 14,
  },
});
