import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { Ionicons, FontAwesome } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { db, auth } from '../../firebase/config';
import { ref, onValue, remove } from 'firebase/database';

type FavoriteItem = {
  id: string;
  name: string;
  image: string; // URL string
  rating: number;
  price: number;
};

const FavoritesScreen = () => {
  const router = useRouter();
  const [favorites, setFavorites] = useState<FavoriteItem[]>([]);

  useEffect(() => {
    const user = auth.currentUser;
    if (!user) return;

    const favRef = ref(db, `users/${user.uid}/favorites`);

    const unsubscribe = onValue(favRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const favList = Object.values(data) as FavoriteItem[];
        setFavorites(favList);
      } else {
        setFavorites([]);
      }
    });

    return () => unsubscribe();
  }, []);

  const removeFavorite = async (burgerId: string) => {
    const user = auth.currentUser;
    if (!user) return;

    await remove(ref(db, `users/${user.uid}/favorites/${burgerId}`));
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* Header */}
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="arrow-back" size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.title}>Your Favorites</Text>
        <View style={{ width: 24 }} />
      </View>

      {/* Favorites List */}
      {favorites.length === 0 ? (
        <Text style={styles.emptyText}>You have not added any favorites yet!</Text>
      ) : (
        favorites.map((burger) => (
          <View key={burger.id} style={styles.card}>
            <TouchableOpacity
              style={styles.imageWrapper}
              onPress={() =>
                router.push({
                  pathname: '/burger-details/[id]',
                  params: { id: burger.id },
                })
              }
            >
              <Image source={{ uri: burger.image }} style={styles.image} />
            </TouchableOpacity>

            <View style={styles.info}>
              <Text style={styles.name}>{burger.name}</Text>
              <View style={styles.ratingRow}>
                <Ionicons name="star" size={14} color="#FFC107" />
                <Text style={styles.rating}>{burger.rating.toFixed(1)}</Text>
              </View>
              <Text style={styles.price}>PKR {burger.price}</Text>
            </View>

            <TouchableOpacity onPress={() => removeFavorite(burger.id)}>
              <FontAwesome name="heart" size={20} color="red" style={styles.heartIcon} />
            </TouchableOpacity>
          </View>
        ))
      )}
    </ScrollView>
  );
};

export default FavoritesScreen;

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#fff',
    flexGrow: 1,
  },
  headerRow: {
    marginTop: 25,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  backButton: {
    width: 24,
    alignItems: 'flex-start',
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    flex: 1,
  },
  emptyText: {
    fontSize: 16,
    color: '#999',
    textAlign: 'center',
    marginTop: 50,
  },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f9f9f9',
    borderRadius: 10,
    padding: 12,
    marginBottom: 15,
    elevation: 2,
  },
  imageWrapper: {
    marginRight: 15,
  },
  image: {
    width: 60,
    height: 60,
    borderRadius: 8,
  },
  info: {
    flex: 1,
  },
  name: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFA726',
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  rating: {
    fontSize: 14,
    marginLeft: 5,
    color: '#555',
  },
  price: {
    fontSize: 14,
    fontWeight: 'bold',
    marginTop: 5,
    color: '#333',
  },
  heartIcon: {
    marginLeft: 10,
  },
});
