import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Alert,
  Modal,
  ActivityIndicator,
} from 'react-native';
import { ref, push, set, remove, onValue, get, update } from 'firebase/database';
import { db } from '../../firebase/config';
import { MaterialIcons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';

interface Burger {
  id: string;
  name: string;
  price: number;
  description: string;
  imageUrl?: string;
  image?: string;
  rating?: number;
  category?: string;
}

interface BurgerData {
  name: string;
  price: number;
  description: string;
  image: string;
  rating: number;
  category: string;
}

export default function AdminDashboard() {
  const [burgers, setBurgers] = useState<Burger[]>([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingBurger, setEditingBurger] = useState<Burger | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [newBurger, setNewBurger] = useState({
    name: '',
    price: '',
    description: '',
    imageUrl: '',
    category: '',
  });

  const router = useRouter();

  useEffect(() => {
    setIsAdmin(true);
    setLoading(false);
  }, [router]);

  useEffect(() => {
    if (!isAdmin) return;
    const burgersRef = ref(db, 'burgers');
    const unsubscribe = onValue(burgersRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const burgerList = Object.entries(data).map(([id, burger]: [string, any]) => ({
          id,
          ...burger,
        }));
        setBurgers(burgerList);
      }
    });
    return () => unsubscribe();
  }, [isAdmin]);

const handleAddBurger = async () => {
  try {
    const burgersRef = ref(db, 'burgers');
    const newBurgerRef = push(burgersRef);

    const parsedPrice = parseFloat(newBurger.price);
    if (isNaN(parsedPrice)) {
      Alert.alert('Invalid Input', 'Please enter a valid price.');
      return;
    }

    const burgerData: BurgerData = {
      name: newBurger.name.trim(),
      price: parsedPrice,
      description: newBurger.description.trim(),
      rating: 0,
      image: newBurger.imageUrl?.trim() || 'https://via.placeholder.com/150',
      category: newBurger.category.trim() || 'Classic',
    };

    // ✅ Main burger is added here
    await set(newBurgerRef, burgerData);

    // ✅ Try to update user favorites, but don't crash if it fails
    try {
      const usersRef = ref(db, 'users');
      const snapshot = await get(usersRef);

      if (snapshot.exists()) {
        const users = snapshot.val();
        const updates: { [key: string]: any } = {};

        Object.keys(users).forEach(userId => {
          if (userId && users[userId]) {
            updates[`users/${userId}/favorites/${newBurgerRef.key}`] = {
              id: newBurgerRef.key,
              name: burgerData.name,
              image: burgerData.image,
              rating: burgerData.rating,
              price: burgerData.price,
              timestamp: new Date().toISOString(),
            };
          }
        });

        if (Object.keys(updates).length > 0) {
          await update(ref(db), updates); // ✅ Only this might fail
        }
      }
    } catch (favErr) {
      console.warn('Failed to update user favorites:', favErr);
      // Don't throw error — let it pass
    }

    setNewBurger({ name: '', price: '', description: '', imageUrl: '', category: '' });
    setModalVisible(false);
    Alert.alert('Success', 'Burger added successfully!');
  } catch (err) {
    console.error('Add burger error:', err);
    Alert.alert('Error', 'Failed to add burger');
  }
};


  const handleUpdateBurger = async () => {
    if (!editingBurger) return;

    try {
      const burgerRef = ref(db, `burgers/${editingBurger.id}`);
      const updateData: BurgerData = {
        name: editingBurger.name,
        price: parseFloat(String(editingBurger.price)),
        description: editingBurger.description,
        rating: editingBurger.rating || 5.0,
        image: editingBurger.imageUrl?.trim() || editingBurger.image || 'https://via.placeholder.com/150',
        category: editingBurger.category || 'Classic',
      };

      await set(burgerRef, updateData);
      setEditingBurger(null);
      Alert.alert('Success', 'Burger updated successfully!');
    } catch (err) {
      console.error('Update burger error:', err);
      Alert.alert('Error', 'Failed to update burger');
    }
  };

  const handleDeleteBurger = async (burgerId: string) => {
    Alert.alert(
      'Confirm Delete',
      'Are you sure you want to delete this burger?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              const burgerRef = ref(db, `burgers/${burgerId}`);
              await remove(burgerRef);
              Alert.alert('Success', 'Burger deleted successfully!');
            } catch (err) {
              console.error('Delete burger error:', err);
              Alert.alert('Error', 'Failed to delete burger');
            }
          },
        },
      ]
    );
  };

  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color="#007AFF" />
      </View>
    );
  }

  if (!isAdmin) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center', padding: 20 }]}>
        <Text style={[styles.headerText, { marginBottom: 10 }]}>Access Denied</Text>
        <Text style={{ textAlign: 'center' }}>
          This area is restricted to admin users only. Please login with admin credentials.
        </Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerText}>Admin Dashboard</Text>
        <TouchableOpacity style={styles.addButton} onPress={() => setModalVisible(true)}>
          <Text style={styles.addButtonText}>Add New Burger</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.burgersList}>
        {burgers.map((burger) => (
          <View key={burger.id} style={styles.burgerItem}>
            <View style={styles.burgerInfo}>
              <Text style={styles.burgerName}>{burger.name}</Text>
              <Text style={styles.burgerPrice}>PKR {burger.price}</Text>
              <Text style={styles.burgerDescription} numberOfLines={2}>
                {burger.description}
              </Text>
            </View>
            <View style={styles.actionButtons}>
              <TouchableOpacity onPress={() => setEditingBurger(burger)} style={styles.editButton}>
                <MaterialIcons name="edit" size={24} color="#007AFF" />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => handleDeleteBurger(burger.id)} style={styles.deleteButton}>
                <MaterialIcons name="delete" size={24} color="#FF3B30" />
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </View>

      {/* Add Burger Modal */}
      <Modal animationType="slide" transparent={true} visible={modalVisible} onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Add New Burger</Text>
            <TextInput
              style={styles.input}
              placeholder="Burger Name"
              value={newBurger.name}
              onChangeText={(text) => setNewBurger({ ...newBurger, name: text })}
            />
            <TextInput
              style={styles.input}
              placeholder="Category"
              value={newBurger.category}
              onChangeText={(text) => setNewBurger({ ...newBurger, category: text })}
            />
            <TextInput
              style={styles.input}
              placeholder="Price"
              value={newBurger.price}
              onChangeText={(text) => setNewBurger({ ...newBurger, price: text })}
              keyboardType="decimal-pad"
            />
            <TextInput
              style={styles.input}
              placeholder="Description"
              value={newBurger.description}
              onChangeText={(text) => setNewBurger({ ...newBurger, description: text })}
              multiline
            />
            <TextInput
              style={styles.input}
              placeholder="Image URL"
              value={newBurger.imageUrl}
              onChangeText={(text) => setNewBurger({ ...newBurger, imageUrl: text })}
            />
            <View style={styles.modalButtons}>
              <TouchableOpacity style={[styles.modalButton, styles.cancelButton]} onPress={() => setModalVisible(false)}>
                <Text style={styles.buttonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.modalButton, styles.saveButton]} onPress={handleAddBurger}>
                <Text style={styles.buttonText}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Edit Burger Modal */}
      <Modal animationType="slide" transparent={true} visible={!!editingBurger} onRequestClose={() => setEditingBurger(null)}>
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Edit Burger</Text>
            <TextInput
              style={styles.input}
              placeholder="Burger Name"
              value={editingBurger?.name}
              onChangeText={(text) => setEditingBurger(prev => prev ? { ...prev, name: text } : null)}
            />
            <TextInput
              style={styles.input}
              placeholder="Category"
              value={editingBurger?.category}
              onChangeText={(text) => setEditingBurger(prev => prev ? { ...prev, category: text } : null)}
            />
            <TextInput
              style={styles.input}
              placeholder="Price"
              value={String(editingBurger?.price)}
              onChangeText={(text) =>
                setEditingBurger(prev => prev ? { ...prev, price: parseFloat(text) || 0 } : null)
              }
              keyboardType="decimal-pad"
            />
            <TextInput
              style={styles.input}
              placeholder="Description"
              value={editingBurger?.description}
              onChangeText={(text) => setEditingBurger(prev => prev ? { ...prev, description: text } : null)}
              multiline
            />
            <TextInput
              style={styles.input}
              placeholder="Image URL"
              value={editingBurger?.imageUrl}
              onChangeText={(text) => setEditingBurger(prev => prev ? { ...prev, imageUrl: text } : null)}
            />
            <View style={styles.modalButtons}>
              <TouchableOpacity style={[styles.modalButton, styles.cancelButton]} onPress={() => setEditingBurger(null)}>
                <Text style={styles.buttonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.modalButton, styles.saveButton]} onPress={handleUpdateBurger}>
                <Text style={styles.buttonText}>Update</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
  paddingTop: 60,        
  padding: 20,
  backgroundColor: '#fff',
  flexDirection: 'row',
  justifyContent: 'space-between',
  alignItems: 'center',
  borderBottomWidth: 1,
  borderBottomColor: '#e0e0e0',
  },
  headerText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  addButton: {
    backgroundColor: '#007AFF',
    padding: 10,
    borderRadius: 8,
  },
  addButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  burgersList: {
    padding: 16,
  },
  burgerItem: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  burgerInfo: {
    flex: 1,
    marginRight: 16,
  },
  burgerName: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  burgerPrice: {
    fontSize: 16,
    color: '#007AFF',
    marginBottom: 4,
  },
  burgerDescription: {
    color: '#666',
  },
  actionButtons: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  editButton: {
    marginRight: 16,
  },
  deleteButton: {},
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 20,
    width: '90%',
    maxWidth: 400,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
    fontSize: 16,
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  modalButton: {
    flex: 1,
    padding: 12,
    borderRadius: 8,
    marginHorizontal: 8,
  },
  cancelButton: {
    backgroundColor: '#FF3B30',
  },
  saveButton: {
    backgroundColor: '#007AFF',
  },
  buttonText: {
    color: '#fff',
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 16,
  },
});
