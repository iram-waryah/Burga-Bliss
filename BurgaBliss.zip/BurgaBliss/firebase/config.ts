// firebase/config.ts
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getDatabase } from 'firebase/database';

const firebaseConfig = {
 apiKey: "AIzaSyAstVMzIBAp_IgmlXp8whGKopX2jLh-0No",
  authDomain: "burgabliss-2528a.firebaseapp.com",
  databaseURL: "https://burgabliss-2528a-default-rtdb.firebaseio.com/",
  projectId: "burgabliss-2528a",
  storageBucket: "burgabliss-2528a.firebasestorage.app",
  messagingSenderId: "1073482248942",
  appId: "1:1073482248942:web:25a6e841eeb839ce26f9ff"

};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getDatabase(app);
