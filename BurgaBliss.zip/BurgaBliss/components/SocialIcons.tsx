import React from 'react';
import { View, Image, StyleSheet } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';

export default function SocialIcons() {
  return (
    <View style={styles.socialContainer}>
      <FontAwesome name="facebook" size={28} color="#4267B2" />
      <Image
        source={{ uri: 'https://upload.wikimedia.org/wikipedia/commons/4/4e/Gmail_Icon.png' }}
        style={styles.socialIcon}
      />
      <FontAwesome name="twitter" size={28} color="#1DA1F2" />
    </View>
  );
}

const styles = StyleSheet.create({
  socialContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 24,
    marginBottom: 30,
  },
  socialIcon: {
    width: 28,
    height: 28,
    resizeMode: 'contain',
  },
});
