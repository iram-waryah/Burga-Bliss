import React from 'react';
import { View, Image, StyleSheet } from 'react-native';

export default function LogoHeader() {
  return (
    <View style={styles.header}>
      <Image
        source={require('../assets/images/burgabliss-logo.png')}
        style={styles.logo}
        resizeMode="contain"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    width: '100%',
    backgroundColor: '#FFC107',
    alignItems: 'center',
    paddingVertical: 40,
    borderBottomLeftRadius: 40,
    borderBottomRightRadius: 40,
  },
  logo: {
    width: 150,
    height: 100,
  },
});
